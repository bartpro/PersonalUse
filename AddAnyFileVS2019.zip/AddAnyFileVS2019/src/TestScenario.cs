﻿using System.Collections.Generic;

namespace SpecflowStepGenerator
{
	public class TestScenario
	{

		public TestScenario()
		{
			TestCaseId = new List<string>();
			GivenStep = new List<string>();
			WhenStep = new List<string>();
			ThenStep = new List<string>();
			AndStep = new List<string>();
		}

		public List<string> TestCaseId { get; set; }
		public string ScenarioName { get; set; }
		public List<string> GivenStep { get; set; }
		public List<string> WhenStep { get; set; }
		public List<string> ThenStep { get; set; }
		public List<string> AndStep { get; set; }
		public string FirstTableRow { get; set; }
	}
}