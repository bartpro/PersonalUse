﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace SpecflowStepGenerator
{
	public static class StepFileWriter
	{
		private static List<string> _references = new List<string>()
		{ "using TechTalk.Specflow;", "using System;", "using GuiSpecflow.Extensions;", $"using GuiUtils;{NewLine()}"};

		private static List<string> _duplicateSteps = new List<string>();

		private static string NameSpace(string folderPath)
		{
			string folderName = folderPath.Split('\\').Last();
			return $"namespace GuiSpecFlow.Steps.{folderName}";
		}

		private static string GivenTag(string givenStep, string scope = "")
		{
			var regex = new Regex(Regex.Escape("Given "));
			var step = regex.Replace(AddSpecflowParameterSymbol(givenStep), string.Empty, 1);
			return $"[Given(\"{step}\"){scope}]";
		}

		private static string WhenTag(string whenStep, string scope = "")
		{
			var regex = new Regex(Regex.Escape("When "));
			var step = regex.Replace(AddSpecflowParameterSymbol(whenStep), string.Empty, 1);
			return $"[Given(\"{step}\"){scope}]";
		}

		private static string ThenTag(string thenStep, string scope = "")
		{
			var regex = new Regex(Regex.Escape("Then "));
			var step = regex.Replace(AddSpecflowParameterSymbol(thenStep), string.Empty, 1);
			return $"[Given(\"{step}\"){scope}]";
		}
		private static string AndTag(string andStep, string scope = "")
		{
			var regex = new Regex(Regex.Escape("And "));
			var step = regex.Replace(AddSpecflowParameterSymbol(andStep), string.Empty, 1);
			return $"[Given(\"{step}\"){scope}]";
		}
		private static string BindingAndScopeTag(string testFeatureId)
			=> $"[Binding, Scope(Tag = \"{testFeatureId}\")]";
		private static string TestCaseScope(string scenarioName, string featureId)
			=> $",{NewLine()}{WhiteSpace(8)}Scope(Scenario = \"{scenarioName}\", Tag = \"{featureId}\")";
		private static string AddSpecflowParameterSymbol(string stepDefinitions)
		{
			if (stepDefinitions.Contains("<") && stepDefinitions.Contains(">"))
			{
				string SpeflowParameterHolder = stepDefinitions.Replace(SpeflowParameter(stepDefinitions), "(.*)");
				return SpeflowParameterHolder;
			}
			return stepDefinitions;
		}
		private static string SpeflowParameter(string stepDefinitions)
		{
			if (stepDefinitions.Contains("<") && stepDefinitions.Contains(">"))
			{
				string speflowParameter = stepDefinitions.Substring(stepDefinitions.IndexOf("<"),
				(stepDefinitions.IndexOf(">") - stepDefinitions.IndexOf("<")) + 1);
				return speflowParameter;
			}
			else
				return String.Empty;
		}
		public static void CheckForDuplicateSteps(TestFeature testFeature, TestScenario testScenario)
		{
			List<string> allGivenSteps = new List<string>();
			List<string> allAndSteps = new List<string>();
			List<string> allWhenSteps = new List<string>();
			List<string> allThenSteps = new List<string>();

			foreach (var scenario in testFeature.TestScenarios)
			{
				allGivenSteps.AddRange(scenario.GivenStep);
				allAndSteps.AddRange(scenario.AndStep);
				allWhenSteps.AddRange(scenario.WhenStep);
				allThenSteps.AddRange(scenario.ThenStep);
			}

			List<string> GivenDuplicates = allGivenSteps.GroupBy(x => x)
										.Where(g => g.Count() > 1)
										.Select(x => x.Key).ToList();

			List<string> AndDuplicates = allAndSteps.GroupBy(x => x)
										.Where(g => g.Count() > 1)
										.Select(x => x.Key).ToList();

			List<string> WhenDuplicates = allWhenSteps.GroupBy(x => x)
										.Where(g => g.Count() > 1)
										.Select(x => x.Key).ToList();

			List<string> ThenDuplicates = allThenSteps.GroupBy(x => x)
							.Where(g => g.Count() > 1)
							.Select(x => x.Key).ToList();

			_duplicateSteps.AddRange(GivenDuplicates);
			_duplicateSteps.AddRange(AndDuplicates);
			_duplicateSteps.AddRange(WhenDuplicates);
			_duplicateSteps.AddRange(ThenDuplicates);
		}
		private static string ClassAndConstuctorName(string featureId, List<string> testCaseIds, string scenarioName)
		{
			string PascalScenarioName = ToPascalCase(scenarioName);
			string formattedFeatureId = featureId.Replace("pid:", string.Empty).Replace("-", "_");
			string testCaseId = string.Empty;

			if (testCaseIds.Count > 1)
			{
				testCaseId = $"_ATC_{testCaseIds.First()}-{testCaseIds.Last().Replace("REV-", string.Empty)}";
			}
			else
			{
				testCaseId = testCaseIds.First();
			}
			return string.Concat(formattedFeatureId, "_", testCaseId, "_", PascalScenarioName);
		}

		private static string ClassName(string featureId, List<string> testCaseIds, string scenarioName)
		{
			return string.Concat("public class ", ClassAndConstuctorName(featureId, testCaseIds, scenarioName));
		}

		private static string ClassConstructorName(string featureId, List<string> testCaseIds, string scenarioName)
		{
			return string.Concat(ClassAndConstuctorName(featureId, testCaseIds, scenarioName),
				"(FeatureContext featureContext, ScenarioContext scenarioContext)");
		}

		private static string StepMethodName(string stepName)
		{
			string parameter = SpeflowParameter(stepName);

			string parameterCamelCase = string.Empty;
			string PascalStepName = string.Empty;
			string stepNameWithoutParameter = string.Empty;

			if (parameter != string.Empty)
			{
				parameterCamelCase = ToCamelCase(parameter);
				stepNameWithoutParameter = stepName.Replace(parameter, string.Empty);
				PascalStepName = ToPascalCase(stepNameWithoutParameter);
			}
			else
				PascalStepName = ToPascalCase(stepName);

			string methodName = $"public async Task {PascalStepName}({parameterCamelCase})";

			var regex = new Regex(Regex.Escape("And"));
			methodName = regex.Replace(AddSpecflowParameterSymbol(methodName), string.Empty, 1);

			return methodName;
		}

		private static string ToCamelCase(string parameter)
		{
			parameter = parameter.Replace("<", "").Replace(">", "");
			var wordArray = parameter.Split(' ');

			if (wordArray.Length < 2)
				return string.Concat("object ", parameter);

			var camelCaseString = string.Empty;
			var PascalCaseString = string.Empty;
			foreach (var word in wordArray)
			{
				var PascalCaseWord = word[0].ToString().ToUpper() + word.Substring(1);
				PascalCaseString = PascalCaseString + PascalCaseWord;
			}

			camelCaseString = PascalCaseString[0].ToString().ToLower() + PascalCaseString.Substring(1);
			return string.Concat("object ", camelCaseString);
		}

		private static string NotImplementedException() => "throw new NotImplementedException();";

		// Main method
		public static void WriteStepFiles(string source, string folderPath)
		{
			TestFeature testFeature = FeatureFileReader.ReadActiveFile(source);

			testFeature.TestScenarios.ForEach(scenario => WriteStepFile(testFeature, scenario, folderPath));
		}

		public static void WriteStepFile(TestFeature testFeature, TestScenario testScenario, string folderPath)
		{
			try
			{
				File.WriteAllLines(Path
			   .Combine(folderPath, string.Concat(ClassAndConstuctorName(testFeature.FeatureId, testScenario.TestCaseId, testScenario.ScenarioName), ".cs")),
					 ScenarioLineList(testFeature, testScenario, folderPath));
			}
			catch (DirectoryNotFoundException e)
			{

			}
		}

		private static List<string> ScenarioLineList(TestFeature testFeature, TestScenario testScenario, string folderPath)
		{
			CheckForDuplicateSteps(testFeature, testScenario);

			List<string> lines = new List<string>();

			// References
			lines.AddRange(_references);

			// Namespace
			lines.Add(NameSpace(folderPath));
			lines.Add("{");

			// Binding
			lines.Add(WithWhiteSpace(4, BindingAndScopeTag(testFeature.FeatureId)));

			// Class name
			lines.Add(WithWhiteSpace(4, ClassName(testFeature.FeatureId, testScenario.TestCaseId, testScenario.ScenarioName)));
			lines.Add(WithWhiteSpace(4, "{"));


			// Class constructor
			lines.Add(WithWhiteSpace(8, ClassConstructorName(testFeature.FeatureId, testScenario.TestCaseId, testScenario.ScenarioName)));
			lines.Add(WithWhiteSpace(8, "{"));
			lines.Add(WithWhiteSpaceAndLineChange(8, "}"));

			// Given tag and method block
			foreach (var step in testScenario.GivenStep)
			{
				if (_duplicateSteps.Contains(step))
					lines.Add(WithWhiteSpace(8, GivenTag(step, TestCaseScope(testScenario.ScenarioName, testFeature.FeatureId))));
				else
					lines.Add(WithWhiteSpace(8, GivenTag(step)));

				lines.Add(WithWhiteSpace(8, StepMethodName(step)));
				lines.Add(WithWhiteSpace(8, "{"));
				lines.Add(WithWhiteSpace(12, NotImplementedException()));
				lines.Add(WithWhiteSpaceAndLineChange(8, "}"));
			}

			// And tag and method block
			foreach (var step in testScenario.AndStep)
			{
				if (_duplicateSteps.Contains(step))
					lines.Add(WithWhiteSpace(8, AndTag(step, TestCaseScope(testScenario.ScenarioName, testFeature.FeatureId))));
				else
					lines.Add(WithWhiteSpace(8, AndTag(step)));

				lines.Add(WithWhiteSpace(8, StepMethodName(step)));
				lines.Add(WithWhiteSpace(8, "{"));
				lines.Add(WithWhiteSpace(12, NotImplementedException()));
				lines.Add(WithWhiteSpaceAndLineChange(8, "}"));
			}

			// When tag and method block
			foreach (var step in testScenario.WhenStep)
			{
				if (_duplicateSteps.Contains(step))
					lines.Add(WithWhiteSpace(8, WhenTag(step, TestCaseScope(testScenario.ScenarioName, testFeature.FeatureId))));
				else
					lines.Add(WithWhiteSpace(8, WhenTag(step)));

				lines.Add(WithWhiteSpace(8, StepMethodName(step)));
				lines.Add(WithWhiteSpace(8, "{"));
				lines.Add(WithWhiteSpace(12, NotImplementedException()));
				lines.Add(WithWhiteSpaceAndLineChange(8, "}"));
			}

			// Then tag and method block
			foreach (var step in testScenario.ThenStep)
			{
				if (_duplicateSteps.Contains(step))
					lines.Add(WithWhiteSpace(8, ThenTag(step, TestCaseScope(testScenario.ScenarioName, testFeature.FeatureId))));
				else
					lines.Add(WithWhiteSpace(8, ThenTag(step)));

				lines.Add(WithWhiteSpace(8, StepMethodName(step)));
				lines.Add(WithWhiteSpace(8, "{"));
				lines.Add(WithWhiteSpace(12, NotImplementedException()));
				lines.Add(WithWhiteSpaceAndLineChange(8, "}"));
			}

			// Closing bracket for class
			lines.Add(WithWhiteSpace(4, "}"));

			// Closing bracket for namespace
			lines.Add("}");

			return lines;
		}

		private static string ConvertListToStringWithNewLine(TestFeature testFeature, TestScenario testScenario, string folderPath)
		{
			List<string> lines = ScenarioLineList( testFeature, testScenario, folderPath);
			return String.Join(NewLine(), lines.ToArray());
		}

		private static string ToPascalCase(string featureName)
		{
			var wordArray = featureName.Split(' ');
			string pascalString = string.Empty;
			foreach (var word in wordArray)
			{
				if (string.IsNullOrEmpty(word))
					continue;
				var pascalWord = word[0].ToString().ToUpper() + word.Substring(1);
				pascalString = pascalString + pascalWord;
			}
			return pascalString;
		}

		private static string WhiteSpace(int count)
		{
			return new string(' ', count);
		}

		private static string WithWhiteSpace(int count, string lineString)
		{
			return string.Concat(WhiteSpace(count), lineString);
		}

		private static string WithExtraLineChange(string lineString)
		{
			return string.Concat(lineString, NewLine());
		}

		private static string WithWhiteSpaceAndLineChange(int count, string lineString)
		{
			return string.Concat(WhiteSpace(count), lineString, NewLine());
		}
		private static string NewLine() => Environment.NewLine;
	}
}