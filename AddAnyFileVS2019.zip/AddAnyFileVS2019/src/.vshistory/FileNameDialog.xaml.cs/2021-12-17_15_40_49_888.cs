﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media.Imaging;

namespace MadsKristensen.AddAnyFile
{
	public partial class FileNameDialog : Window
	{
		private FolderBrowserDialog folderBrowserDialog;
		private const string DEFAULT_TEXT = "Enter full path...";

		public FileNameDialog()
		{
			InitializeComponent();

			lblFolder.Content = "Full Path: ";

			Loaded += (s, e) =>
			{
				Icon = BitmapFrame.Create(new Uri("pack://application:,,,/AddAnyFile;component/Resources/icon.png", UriKind.RelativeOrAbsolute));
				Title = "Specflow Step Generator";
				SetRandomTip();

				txtName.Focus();
				txtName.CaretIndex = 0;
				txtName.Text = DEFAULT_TEXT;
				txtName.Select(0, txtName.Text.Length);

				txtName.PreviewKeyDown += (a, b) =>
				{
					if (b.Key == Key.Escape)
					{
						if (string.IsNullOrWhiteSpace(txtName.Text) || txtName.Text == DEFAULT_TEXT)
						{
							Close();
						}
						else
						{
							txtName.Text = string.Empty;
						}
					}
					else if (txtName.Text == DEFAULT_TEXT)
					{
						txtName.Text = string.Empty;
						btnCreate.IsEnabled = true;
					}
				};

			};
		}

		public string Input => txtName.Text.Trim();

		private void Button_Click(object sender, RoutedEventArgs e)
		{
			DialogResult = true;
			Close();
		}

		private void Browse_Button_Click(object sender, RoutedEventArgs e)
		{
			folderBrowserDialog = new FolderBrowserDialog();
			folderBrowserDialog.ShowNewFolderButton = true;
			DialogResult result = folderBrowserDialog.ShowDialog();
			if (result == System.Windows.Forms.DialogResult.OK && !string.IsNullOrWhiteSpace(folderBrowserDialog.SelectedPath))
			{
				txtName.Text = folderBrowserDialog.SelectedPath;
			}
		}

	}
}
