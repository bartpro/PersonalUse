﻿using EnvDTE;

using EnvDTE80;

using Microsoft;
using Microsoft.VisualStudio;
using Microsoft.VisualStudio.Shell;
using Microsoft.VisualStudio.Text;
using Microsoft.VisualStudio.Threading;
using SpecflowStepGenerator;
using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;

namespace MadsKristensen.AddAnyFile
{
	[PackageRegistration(UseManagedResourcesOnly = true, AllowsBackgroundLoading = true)]
	[InstalledProductRegistration("#110", "#112", Vsix.Version, IconResourceID = 400)]
	[ProvideMenuResource("Menus.ctmenu", 1)]
	[Guid(PackageGuids.guidAddAnyFilePkgString)]
	public sealed class AddAnyFilePackage : AsyncPackage
	{

		public static DTE2 _dte;

		public DirectoryInfo DirectoryInfo { get; private set; }

		protected async override System.Threading.Tasks.Task InitializeAsync(CancellationToken cancellationToken, IProgress<ServiceProgressData> progress)
		{
			await JoinableTaskFactory.SwitchToMainThreadAsync();

			_dte = await GetServiceAsync(typeof(DTE)) as DTE2;
			Assumes.Present(_dte);

			Logger.Initialize(this, Vsix.Name);

			if (await GetServiceAsync(typeof(IMenuCommandService)) is OleMenuCommandService mcs)
			{
				CommandID menuCommandID = new CommandID(PackageGuids.guidAddAnyFileCmdSet, PackageIds.cmdidMyCommand);
				OleMenuCommand menuItem = new OleMenuCommand(ExecuteAsync, menuCommandID);
				mcs.AddCommand(menuItem);
			}
		}

		private void ExecuteAsync(object sender, EventArgs e)
		{
			//NewItemTarget target = NewItemTarget.Create(_dte);

			string activeFilePath = GetActiveFilePath(_dte);
			if (string.IsNullOrEmpty(activeFilePath))
			{
				return;
			}

			if (!activeFilePath.EndsWith(".feature"))
			{
				MessageBox.Show(
				"The file you are trying to generate step files from it invalid." +
				"\n Only supported file format are feature files ending with .feature",
				"Invalid File Format",
				MessageBoxButton.OK,
				MessageBoxImage.Error);
				return;
			}

			if (activeFilePath == null)
			{
				MessageBox.Show(
						"Could not determine active document file path.",
						Vsix.Name,
						MessageBoxButton.OK,
						MessageBoxImage.Error);
				return;
			}

			string folderPath = PromptForFileName().TrimStart('/', '\\').Replace("/", "\\");

			if (string.IsNullOrEmpty(folderPath))
			{
				return;
			}

			try
				{
					AddItemAsync(folderPath, activeFilePath).Forget();
				}
				catch (Exception ex) when (!ErrorHandler.IsCriticalException(ex))
				{
					Logger.Log(ex);
					MessageBox.Show(
							$"Error creating files':{Environment.NewLine}{ex.Message}",
							Vsix.Name,
							MessageBoxButton.OK,
							MessageBoxImage.Error);
				}
			}

		private string GetActiveFilePath(DTE2 dte)
		{
			return dte.ActiveDocument?.FullName;
		}
	
		private async System.Threading.Tasks.Task AddItemAsync(string folderPath, string activeFilePath)
		{

			await AddFileAsync(folderPath, activeFilePath);
		}

		private async System.Threading.Tasks.Task AddFileAsync(string folderPath, string activeFilePath)
		{
			await JoinableTaskFactory.SwitchToMainThreadAsync();
			FileInfo file;

			TestFeature testFeature = FeatureFileReader.ReadActiveFile(activeFilePath);

			if (!Directory.Exists(folderPath))
			{
				Directory.CreateDirectory(folderPath);
			}

			foreach (var testScenario in testFeature.TestScenarios)
				{
					if (testScenario is null)
						continue;
					else
						await WriteFileAsync(folderPath, testFeature, testScenario);
				}
			
		}

		private static async Task<int> WriteFileAsync(string folderPath, TestFeature testFeature, TestScenario testScenario)
		{
			string fullFilePath = Path
			   .Combine(folderPath, string.Concat(StepFileWriter.ClassAndConstuctorName(testFeature.FeatureId, testScenario.TestCaseId, testScenario.ScenarioName), ".cs"));
			string content = StepFileWriter.GetStepFileContent(testFeature, testScenario, folderPath);
			await WriteToDiskAsync(fullFilePath, content);

			MessageBox.Show(
					"Writing files success!",
					Vsix.Name,
					MessageBoxButton.OK,
					MessageBoxImage.Error);

			return 0;
		}

		private static async System.Threading.Tasks.Task WriteToDiskAsync(string file, string content)
		{
			using (StreamWriter writer = new StreamWriter(file, false, new UTF8Encoding(true)))
			{
				await writer.WriteAsync(content);
			}


		}

		private string PromptForFileName()
		{
			FileNameDialog dialog = new FileNameDialog()
			{
				Owner = Application.Current.MainWindow
			};

			bool? result = dialog.ShowDialog();
			return (result.HasValue && result.Value) ? dialog.Input : string.Empty;
		}

	}
}