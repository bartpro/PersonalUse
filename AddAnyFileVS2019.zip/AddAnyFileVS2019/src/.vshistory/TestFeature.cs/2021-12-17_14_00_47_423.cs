﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpecflowStepGenerator
{
	public class TestFeature
	{
		public TestFeature(List<TestScenario> testScenarios)
		{
			TestScenarios = testScenarios;
		}

		public string FeatureName { get; set; }
		public string FeatureId { get; set; }
		public List<TestScenario> TestScenarios { get; set; }
	}
}
