﻿using System.IO;

namespace SpecflowStepGenerator
{
	public static class FeatureFileReader
	{
		private static int _scenariosUnderWork = 0; // Start from zero to get past first scenario, otherwise will add empty test scenario.

		public static TestFeature ReadActiveFile(string filePath)
		{
			int _
			TestFeature testFeature = new TestFeature();
			TestScenario testScenario = new TestScenario();

			using (FileStream activeDoc = File.Open(filePath, FileMode.Open, FileAccess.Read))
			{
				using (StreamReader streamReader = new StreamReader(activeDoc))
				{
					while (!streamReader.EndOfStream)
					{
						var line = streamReader.ReadLine().Trim();

						switch (line)
						{
							case string a when a.Contains("@pid:"):
								GetFeatureId(line, ref testFeature);
								break;

							case string b when b.StartsWith("Feature:"):
								GetFeatureName(line, ref testFeature);
								break;

							case string c when c.Contains("@test-case"):
								_scenariosUnderWork++;
								if (_scenariosUnderWork > 1)
								{
									testFeature.TestScenarios.Add(testScenario);
									testScenario = new TestScenario();
									_scenariosUnderWork = 1;
								}
								GetTestCaseId(line, ref testScenario);
								break;

							case string d when d.StartsWith("Scenario:"):
								GetScenarioName(line, ref testScenario);
								break;

							case string i when i.StartsWith("Scenario Outline:"):

								GetScenarioOutlineName(line, ref testScenario);
								break;

							case string e when e.StartsWith("Given"):
								GetGivenStep(line, ref testScenario);
								break;

							case string f when f.StartsWith("And"):
								GetAndStep(line, ref testScenario);
								break;

							case string g when g.StartsWith("When"):
								GetWhenStep(line, ref testScenario);
								break;

							case string h when h.StartsWith("Then"):
								GetThenStep(line, ref testScenario);
								break;

							case string t when t.StartsWith("|"):
								GetFirstTableRow(line, ref testScenario);
								break;
						}
					}
				}
			}

			testFeature.TestScenarios.Add(testScenario);
			return testFeature;
		}

		private static void GetFirstTableRow(string line, ref TestScenario testScenario)
		{
			if (string.IsNullOrEmpty(testScenario.FirstTableRow))
				testScenario.FirstTableRow = line.Replace("|", "").Trim();
			else
				return;
		}

		private static void GetScenarioOutlineName(string line, ref TestScenario testScenario)
		{
			testScenario.ScenarioName = line.Replace("Scenario Outline:", "").Trim();
		}

		private static void GetThenStep(string line, ref TestScenario testScenario)
		{
			testScenario.ThenStep.Add(line);
		}

		private static void GetWhenStep(string line, ref TestScenario testScenario)
		{
			testScenario.WhenStep.Add(line);
		}

		private static void GetAndStep(string line, ref TestScenario testScenario)
		{
			testScenario.AndStep.Add(line);
		}

		private static void GetGivenStep(string line, ref TestScenario testScenario)
		{
			testScenario.GivenStep.Add(line);
		}

		private static void GetScenarioName(string line, ref TestScenario testScenario)
		{
			testScenario.ScenarioName = line.Replace("Scenario:", "").Trim();
		}

		private static void GetTestCaseId(string line, ref TestScenario testScenario)
		{
			var idList = line.Split(' ');
			foreach (string id in idList)
			{
				if (id.StartsWith("@test-case:"))
					testScenario.TestCaseId.Add(id.Replace("@test-case:", ""));
			}
		}

		private static void GetFeatureName(string line, ref TestFeature testFeature)
		{
			testFeature.FeatureName = line.Replace("Feature:", "").Trim();
		}

		private static void GetFeatureId(string line, ref TestFeature testFeature)
		{
			var idList = line.Split(' ');
			foreach (string id in idList)
				if (id.StartsWith("@pid:"))
					testFeature.FeatureId = id.Replace("@", "");
		}
	}
}